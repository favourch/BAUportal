<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
<title>BAU Online | Students Portal</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="http://portal.beniamerican.org/style.css" />

<script>
function showDiv1() {
   document.getElementById('courses1').style.display = "block";
}
</script>

<script>
function hideDiv1() {
   document.getElementById('courses1').style.display = "none";
}
</script>

<script>
function showDiv2() {
   document.getElementById('courses2').style.display = "block";
}
</script>

<script>
function hideDiv2() {
   document.getElementById('courses2').style.display = "none";
}
</script>

<script>
function showDiv3() {
   document.getElementById('courses3').style.display = "block";
}
</script>

<script>
function hideDiv3() {
   document.getElementById('courses3').style.display = "none";
}
</script>

<script>
function showDiv4() {
   document.getElementById('courses4').style.display = "block";
}
</script>

<script>
function hideDiv4() {
   document.getElementById('courses4').style.display = "none";
}
</script>
<script>
function showDiv5() {
   document.getElementById('courses5').style.display = "block";
}
</script>

<script>
function hideDiv5() {
   document.getElementById('courses5').style.display = "none";
}
</script>

</head>

<body>

<div id="wrapper">
<div id="header">
<a target="_blank" href="http://beniamerican.org">
<img src="http://portal.beniamerican.org/images/header.png" alt="BAU Online Logo" /> </a>
<hr />
<br />
</div>

<div id="content">