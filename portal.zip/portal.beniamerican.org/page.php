<?php include("top.php"); ?>



<div id="pagetitle">page title</div>

<hr /><br />


Operations Here!



<hr />

<?php include("footer.php"); ?>